let osc
let frequency = 50
let amplitude = 1
let button = 0
let radius = 0
let shrink = false
let circleX = 0
let circleY = 0
let noise

function setup() {

	let canvas = createCanvas(windowWidth, windowHeight)
	canvas.parent("p5")

	osc = new p5.Oscillator()
	osc.setType("sine")
	osc.start()
	osc.amp(0)

	noise = new p5.Noise()
	noise.setType("white")
	noise.amp(0)

	env = new p5.Envelope()
	env.setADSR(.01, .3, .6, .7)

	env2 = new p5.Envelope()
	env2.setADSR(.01, .1, .1, .1)

}

function draw() {

noStroke()
	fill(255, 0, 0)
	rect(0, 0, width, height)
	fill(0, 0, 255)
	rect(0, 0, width/2, height)
	fill(255, 255, 20)
	rect(0, height/2, width, height/2)
	fill(0, 160, 0)
	rect(0, height/2, width/2, height)

	push()
	noStroke()
	fill(button, button, button)
	rect(40, 40, 40, 40)
	pop()

	if (radius > 0 && shrink == true) {
		radius -= 1
	}

// 	if (radius == 0) {
// 	shrink = false
// }

	fill(150, 150, 150)
	ellipse(circleX, circleY, radius, radius)
	

}

function windowResized() {
	resizeCanvas(windowWidth, windowHeight)
}

function mousePressed() {

	shrink = false
	osc.amp(env)
	env.triggerAttack()
	
	noise.start()
	noise.amp(env2)
	env2.triggerAttack()
	circleX = mouseX
	circleY = mouseY
	radius = 50

	mouseDragged()
}

function mouseDragged() {

	let frequency = map(mouseY, 0, height, 200, 50)
	osc.freq(frequency)

	circleX = mouseX
	circleY = mouseY

	if (mouseX >= 40 && mouseX <= 80 && mouseY >= 40 && mouseY <= 80) {
	
	} else if (mouseX < width/2 && mouseY < height/2) {
		osc.setType("sawtooth")
	} else if (mouseX > width/2 && mouseY < height/2) {
		osc.setType("square")
	} else if (mouseX < width/2 && mouseY > height/2) {
		osc.setType("sine")
	} else if (mouseX > width/2 && mouseY > height/2) {
		osc.setType("triangle")
	}

	let pan = map(mouseX, 0, width, -1, 1)
	osc.pan(pan)
	
}

function mouseReleased() {
	env.triggerRelease()
	env2.triggerRelease()
	shrink = true
}

function mouseClicked() {
	if (mouseX >= 40 && mouseX <= 80 && mouseY >= 40 && mouseY <= 80 && button == 0) {
		button = 255
	} else if (mouseX >= 40 && mouseX <= 80 && mouseY >= 40 && mouseY <= 80 && button == 255) {
		button = 0
	}

}